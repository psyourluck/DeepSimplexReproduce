#define DINT
#include "umfpack_free_symbolic.c"
