#define DLONG

#include "umf_extend_front.c"
