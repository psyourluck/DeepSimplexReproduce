#define DINT
#include "umf_fsize.c"
