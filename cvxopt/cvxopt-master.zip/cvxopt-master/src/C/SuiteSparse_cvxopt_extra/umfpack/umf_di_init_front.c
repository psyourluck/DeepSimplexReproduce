#define DINT

#include "umf_init_front.c"
