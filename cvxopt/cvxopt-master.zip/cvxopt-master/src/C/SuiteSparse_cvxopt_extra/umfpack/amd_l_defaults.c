#define DLONG

#include "amd_defaults.c"
