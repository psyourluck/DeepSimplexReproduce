#define ZLONG

#include "umf_valid_numeric.c"
