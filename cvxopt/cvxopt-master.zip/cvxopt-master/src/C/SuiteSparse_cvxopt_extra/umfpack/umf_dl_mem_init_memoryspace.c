#define DLONG

#include "umf_mem_init_memoryspace.c"
