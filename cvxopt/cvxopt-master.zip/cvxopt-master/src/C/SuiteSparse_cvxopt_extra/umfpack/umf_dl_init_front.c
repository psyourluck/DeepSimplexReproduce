#define DLONG

#include "umf_init_front.c"
