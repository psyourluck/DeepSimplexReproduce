#define DLONG

#include "umfpack_free_symbolic.c"
