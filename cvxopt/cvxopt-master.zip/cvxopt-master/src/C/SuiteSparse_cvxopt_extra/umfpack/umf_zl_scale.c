#define ZLONG

#include "umf_scale.c"
