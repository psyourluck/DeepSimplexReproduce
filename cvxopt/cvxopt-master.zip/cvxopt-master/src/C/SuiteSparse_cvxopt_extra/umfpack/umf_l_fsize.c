#define DLONG

#include "umf_fsize.c"
