#define ZLONG

#include "umf_get_memory.c"
