#define DINT
#include "umfpack_numeric.c"
