#define ZLONG

#include "umf_garbage_collection.c"
