#define DLONG
#define FIXQ
#include "umf_assemble.c"
