#define ZLONG

#include "umf_mem_alloc_element.c"
